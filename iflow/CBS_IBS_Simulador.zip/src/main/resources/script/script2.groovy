import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import java.time.OffsetDateTime
import java.time.ZoneId

def Message processData(Message message) {
    def causa = message.getProperty("CamelExceptionCaught")
    while (causa?.cause != null && causa.cause != causa) { causa = causa.cause }

    boolean erroCliente = causa instanceof IllegalArgumentException
    int status = erroCliente ? 400 : 500
    def resposta = [
        status    : status,
        erro      : erroCliente ? "REQUISICAO_INVALIDA" : "ERRO_PROCESSAMENTO",
        mensagem  : causa?.message ?: "Erro não identificado",
        ocorridoEm: OffsetDateTime.now(ZoneId.of("America/Sao_Paulo")).toString()
    ]
    message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(resposta)))
    message.setHeader("Content-Type", "application/json")
    message.setHeader("CamelHttpResponseCode", status)
    return message
}